
## Запуск проекта

0. Зайди в папку с проектом `cd grocery`
1. Заполнить переменные окружения в .env
2. Установить зависимости `npm i`
3. Создание БД `npx sequelize-cli db:create`
4. Выполнение миграций `npx sequelize-cli db:migrate`
5. Наполнение БД `npx sequelize-cli db:seed:all`
6. Запустить проект `npm start`


### Hint

- Картинки в БД храняться в виде base64, сайт для конвертации: https://www.browserling.com/tools/image-to-base64

### Backend

```shell
npm install -g sequelize-cli express-generator

express --view=hbs backend # Генерация основы проекта
cd backend

npm install
npm install dotenv express cookie-session sequelize mysql2 cors jsonwebtoken bcryptjs

npx sequelize-cli init

# Создание моделей БД 
npx sequelize-cli model:generate --name User --attributes username:string,personalName:string,email:string,password:string,birthDate:date
npx sequelize-cli model:generate --name UserWallet --attributes balans:decimal,bonus:decimal,userId:integer

npx sequelize-cli model:generate --name Product --attributes title:string,price:decimal,image:blob,description:text,expirationDate:date,storageConditions:text,bonus:decimal

npx sequelize-cli model:generate --name Order --attributes userId:integer,status:string,receiptDate:date,usedBonus:decimal
npx sequelize-cli model:generate --name OrderItem --attributes orderId:integer,productId:integer,productPrice:decimal,count:integer

npx sequelize-cli db:create # Создание базы данных
npx sequelize-cli db:migrate # Создание таблиц


npx sequelize-cli seed:generate --name products
npx sequelize-cli db:seed:all

# Генерация ключей для SECRET_KEY и COOKIE_SECRET
openssl rand -hex 32
openssl rand -hex 32

SET DEBUG=backend:* & npm start # Запуск проекта
```

### Источники

- https://medium.com/@chauhanprincee7/how-to-use-sequelize-for-migrations-with-node-js-and-mysql-6dd78f2082c5
- https://dev.to/pakos/store-imagesfiles-for-api-using-mysqlmariadb-express-and-sequelize-6hj
- https://levelup.gitconnected.com/creating-sequelize-associations-with-the-sequelize-cli-tool-d83caa902233
- https://sequelize.org/docs/v6
- https://www.bezkoder.com/node-js-express-login-example/
- https://www.browserling.com/tools/image-to-base64
