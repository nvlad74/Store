const { authJwt } = require("../middleware");
const ProductService = require("../service/product")
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', [authJwt.verifyToken], async function(req, res, next) {
  const page = parseInt(req.query.page, 10);
  const products = await ProductService.paginate(page || 1, 10, req.query.q || '')
  console.log(products)
  res.render('index', { 
    title: 'Главная', 
    data: products
  });
});

router.get('/login', function(req, res, next) {
  let token = req.session.token;

  if (token) {
    return res.redirect("/");
  }

  // res.render('auth/login', { title: 'Вход', layout: 'auth/layout' });
  res.render('auth/login', { title: 'Вход' });
});

router.get('/register', function(req, res, next) {
  // res.render('auth/register', { title: 'Регистрация', layout: 'auth/layout' });
  res.render('auth/register', { title: 'Регистрация' });
});

module.exports = router;
