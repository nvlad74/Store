const { authJwt } = require("../middleware");
const UserService = require("../service/user")
const {formatDateToRussian} = require("../utils")

var express = require('express');
var router = express.Router();

router.use(function(req, res, next) {
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, Content-Type, Accept"
  );
  next();
});

router.get("/profile",
  [authJwt.verifyToken],
  async (req, res) => {
    const user = await UserService.get(req.userId)
    const wallet = await UserService.getWallet(req.userId)

    const userData = {
      id: user.id,
      username: user.username,
      personalName: user.personalName,
      birthDate: formatDateToRussian(user.birthDate),
      email: user.email,
      'wallet': {
        balans: wallet.balans,
        bonus: wallet.bonus,
      }
    }
    
    res.render('profile', { title: 'Профиль', 'user': userData });
  }
);

router.post("/api/user/wallet",
  [authJwt.verifyToken],
  async (req, res) => {
    const user = await UserService.get({id: req.userId})

    if (user && req.body.balans > 0) {
      result = await UserService.addToWallet(user.id, req.body.balans)
      console.log(result)
      res.status(200).send("Wallet update.")
    } else {
      res.status(403).send("Wallet not update.")
    }
})
// router.get("/api/test/all", (req, res) => {
//   res.status(200).send("Public Content.");
// });

// router.get(
//   "/api/test/user",
//   [authJwt.verifyToken],
//   (req, res) => {
//     res.status(200).send("User Content.");
//   }
// );

module.exports = router;
