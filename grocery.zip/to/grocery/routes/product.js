const { authJwt } = require("../middleware");
const ProductService = require("../service/product")
const OrderService = require("../service/order")
const UserService = require("../service/user")
var express = require('express');
var router = express.Router();


router.get('/product/:id', [authJwt.verifyToken], async function(req, res, next) {
  const productId = parseInt(req.params.id, 10);
  const wallet = await UserService.getWallet(req.userId)

  const product = await ProductService.get(productId)
  res.render('product', { title:  product.title , item: product, 'wallet': wallet});
});

router.get('/order', [authJwt.verifyToken], async function(req, res, next) {
  const items = await OrderService.getCurrentAll(req.userId)
  const wallet = await UserService.getWallet(req.userId)

  res.render('order', { 
    title:  "Корзина", 
    data: items, 
    'wallet': wallet
  });
});

router.get('/history', [authJwt.verifyToken], async function(req, res, next) {
  const items = await OrderService.getCompleted(req.userId)

  res.render('history', { title:  "История заказов", 'data': items });
});

router.post('/api/order', [authJwt.verifyToken], async function(req, res, next) {
  const result = await OrderService.addProduct(
    req.userId, req.body.productId, req.body.count
  )
  return res.status(200).send({message: "complete"})
});

router.post('/api/order/fastbuy', [authJwt.verifyToken], async function(req, res, next) {
  const result = await OrderService.fastBuy(
    req.userId, req.body.productId, req.body.count, req.body.useBonus
  )
  console.log(result)
  return res.status(200).send({message: "complete"})
});

router.post('/api/order/complete', [authJwt.verifyToken], async function(req, res, next) {
  const result = await OrderService.complete(req.userId, req.body.useBonus)
  console.log(result)
  return res.status(200).send({message: "complete"})
});

router.delete('/api/order/product', [authJwt.verifyToken], async function(req, res, next) {
  const result = await OrderService.deleteProduct(req.userId, req.body.productId)
  console.log(result)
  return res.status(200).send({message: "complete"})
});

module.exports = router;
