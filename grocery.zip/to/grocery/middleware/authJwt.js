const jwt = require("jsonwebtoken");
const config = require("../config/auth.config.js");

verifyToken = (req, res, next) => {
  let token = req.session.token;

  if (!token) {
    return res.redirect("/login");
  }

  jwt.verify(token,
             config.secret,
             (err, decoded) => {
              if (err) {
                req.session = null
                return res.redirect("/login");
              }
              req.userId = decoded.id;
              next();
             });
};

const authJwt = {
  verifyToken,
};
module.exports = authJwt;