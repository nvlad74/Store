const UserService = require("../service/user");

checkDuplicateUsernameOrEmail = async (req, res, next) => {
  try {
    // Username
    let user = await UserService.get({
        username: req.body.username
    });

    if (user) {
      return res.status(400).send({
        message: "Failed! Username is already in use!"
      });
    }

    // Email
    user = await UserService.get({
        email: req.body.email
    });

    if (user) {
      return res.status(400).send({
        message: "Failed! Email is already in use!"
      });
    }

    next();
  } catch (error) {
    console.log(error)
    return res.status(500).send({
      message: "Unable to validate Username!"
    });
  }
};

const verifySignUp = {
  checkDuplicateUsernameOrEmail,
};

module.exports = verifySignUp;