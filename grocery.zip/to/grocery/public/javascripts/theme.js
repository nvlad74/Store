
const root = document.documentElement;

document.addEventListener('DOMContentLoaded', () => {
    const 
        theme = document.getElementById('Theme'),
        theme_description = document.getElementById('theme_description')

    document.documentElement.style = "transition: color 0.1618s linear, background-color 0.1618s linear, border-color 0.1618s linear;";

    function apply_theme(index) {
        const { bg, fg, name } = theme_colors[index];

        root.style.setProperty('--bg_color', bg);
        root.style.setProperty('--fg_color', fg);

        theme_description.innerText = name;
        localStorage.setItem("current_theme_index", index)
    }

    function ThemeChange() {
        const
            current_theme = Number(theme.dataset.activated),
            next_theme = (current_theme + 1) % theme_colors.length;


        apply_theme(current_theme);
        theme.dataset.activated = `${next_theme}`;
    }

    // Сохранение темы
    var theme_index = localStorage.getItem("current_theme_index");
    if (theme_index != null) {
        theme.dataset.activated = `${theme_index}`;
    }

    ThemeChange();

    document.getElementById("Theme").addEventListener('click', ThemeChange);
});
