
document.addEventListener('DOMContentLoaded', () => {
    const menuContainer = document.querySelector(".menu-container > .bottom")
    for (const item of Object.entries(menu_items)) {
        const name = item[0]
        const options = item[1]

        const itemElement = document.createElement("a")
        itemElement.id = `menu-${name}`
        itemElement.name = name
        itemElement.href = options.url
        itemElement.innerText = options.title

        menuContainer.appendChild(itemElement)
    }

    window.setActiveMenuItem = (itemName) => {
        for (const name of Object.keys(menu_items)) {
            const menuItem = document.getElementById(`menu-${name}`)
            menuItem.classList.remove("selected-menu")
        }
        document.getElementById(`menu-${itemName}`).classList.add("selected-menu")
    }
})