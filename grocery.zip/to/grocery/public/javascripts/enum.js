/*
    todo: как реализовать независимую привязку к элементу независимо от него и не знаю его расположение
    toDo: смену темы  правого верхнего угла в левый нижний угол
    todo: адаптировать по разрешению экрана
*/

theme_colors = [
    {
        id: "classic",
        name: "классик",
        bg: "#ded5b2",
        fg: "#756010"
    },

    {
        id: "dark",
        name: "темная",
        bg: "#202020",
        fg: "#cdcdcd"
    },

    {
        id: "light",
        name: "светлая",
        bg: "#ccc",
        fg: "#555555"
    },

    {
        id: "contrast",
        name: "контраст",
        bg: "#151515",
        fg: "#ff0"
    }
];

menu_items = {
    main: {
        title: "Главная",
        url: "/"
    },
    profile: {
        title: "Профиль",
        url: "/profile"
    },
    order: {
        title: "Корзина",
        url: "/order"
    },
    history: {
        title: "История",
        url: "/history"
    },
}
