const { Op } = require('sequelize');
const db = require('../models')

const ProductService = {};

ProductService.get = async (id) => {
    return await db.Product.findByPk(id)
}

ProductService.paginate = async(page = 1, limit = 10, titlePart = '') => {
    const offset = (page - 1) * limit
    const { count, rows } = await db.Product.findAndCountAll({
        limit: limit,
        offset: offset,
        where: titlePart != '' ? {
            title: {
                [Op.like]: `%${titlePart}%`
            }
        } : {}
    })

    const totalPages = Math.ceil(count / limit)

    return {
        totalItems: count,
        totalPages: totalPages,
        currentPage: page,
        products: rows,
    };
}

module.exports = ProductService