const db = require('../models')
const config = require("../config/auth.config.js");

const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const UserService = {};

UserService.get = async (options) => {
    return await db.User.findOne({
        where: options
    })
}

UserService.getWallet = async (userId) => {
    const wallets = await db.UserWallet.findOrCreate({
        where: {'userId': userId},
        defaults: {
            'userId': userId,
            balans: 0,
            bonus: 0,
        }
    })
    
    if (wallets.length > 0) {
        return wallets[0]
    } else {
        return undefined
    }
}

UserService.addToWallet = async (userId, balans = 0, bonus = 0) => {
    const wallet = await db.UserWallet.findOne({
        where: {'userId': userId},
    })
    
    return await db.UserWallet.update({
        'balans': Number(wallet.balans) + Number(balans),
        'bonus': Number(wallet.bonus) + Number(bonus),
    }, {
        where: {'userId': userId}
    })
}

UserService.signup = async (req, res) => {
    // Save User to Database
    try {
        const user = await db.User.create({
            username: req.body.username,
            personalName: req.body.personalName,
            email: req.body.email,
            birthDate: req.body.birthDate,
            password: bcrypt.hashSync(req.body.password, 8),
        });
        console.log(user)

        res.send({ message: "Регистрация прошла успешно !" });
    } catch (error) {
        res.status(500).send({ message: error.message });
    }
};

UserService.signin = async (req, res) => {
    try {
        const user = await UserService.get({
            username: req.body.username,
        });

        if (!user) {
            console.log(`Пользователь не найден: ${JSON.stringify(req.body)}`)
            return res.status(401).send({ message: "Неверный логин или пароль !" });
        }

        const passwordIsValid = bcrypt.compareSync(
            req.body.password,
            user.password
        );

        if (!passwordIsValid) {
            console.log(`Неверный пароль: ${JSON.stringify(req.body)}`)
            return res.status(401).send({
                message: "Неверный логин или пароль !",
            });
        }

        const token = jwt.sign({ id: user.id }, config.secret, {
            algorithm: 'HS256',
            allowInsecureKeySizes: true,
            expiresIn: 86400, // 24 hours
        });

        req.session.token = token;

        return res.status(200).send({
            id: user.id,
            username: user.username,
            personalName: user.personalName,
            birthDate: user.birthDate,
            email: user.email,
        });
    } catch (error) {
        return res.status(500).send({ message: error.message });
    }
};

UserService.signout = async (req, res) => {
    try {
        req.session = null;
        return res.status(200).send({
            message: "Вы вышли"
        });
    } catch (err) {
        this.next(err);
    }
};

module.exports = UserService
