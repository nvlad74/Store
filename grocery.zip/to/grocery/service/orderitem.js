const db = require('../models')

const OrderItemService = {};

OrderItemService.get = async (options) => {
    return await db.OrderItem.findOne({
        where: options
    })
}

OrderItemService.all = async (options) => {
    return await db.OrderItem.findAll({
        where: options
    })
}

OrderItemService.create = async (orderId, productId, productPrice, count) => {
    // TODO: добавить валидацию значений
    const item = await OrderItemService.get({
        'orderId': orderId,
        'productId': productId,
    })

    if (item) {
        return await OrderItemService.update(item.id, {
            'productPrice': productPrice,
            'count': item.count + count
        })
    } else {
        return await db.OrderItem.create({
            'orderId': orderId,
            'productId': productId,
            'productPrice': productPrice,
            'count': count
        })
    }
}

OrderItemService.update = async (orderItemId, options) => {
    return await db.OrderItem.update(
        options,
        {
            where: {
                id: orderItemId
            }
        }
    )
}

OrderItemService.delete = async (orderItemId) => {
    return await db.OrderItem.destroy({
        where: {
            id: orderItemId
        }
    })
}

module.exports = OrderItemService