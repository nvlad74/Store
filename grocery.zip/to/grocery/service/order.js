const { Op, or } = require('sequelize');
const db = require('../models')
const UserService = require('./user')
const ProductService = require('./product')
const OrderItemService = require('./orderitem')
const {formatDateToRussian} = require("../utils")


const OrderStatusEnum = {
    current: "Текущий",
    complete: "Выполнен",
}

const OrderService = {};

OrderService.getCurrent = async (userId) => {
    const order = await db.Order.findOrCreate({
        where: {'userId': userId, status: OrderStatusEnum.current},
        defaults: {
            'userId': userId,
            status: OrderStatusEnum.current
        }
    })
    return order[0]
}

OrderService.getCurrentAll = async (userId) => {
    const order = await db.Order.findOrCreate({
        where: {
            'userId': userId,
            status: OrderStatusEnum.current
        }
    })
    const wallet = await UserService.getWallet(userId)
    const orderItems = await OrderItemService.all({
        orderId: order[0].id
    })
    var totalSum = 0
    var newBonus = 0
    var products = []
    for (const orderItem of orderItems) {
        totalSum += orderItem.productPrice * orderItem.count
        const product = await ProductService.get(orderItem.productId)
        newBonus += product.bonus * orderItem.count
        product.price = orderItem.productPrice
        product.count = orderItem.count

        console.log(product)
        products.push(product)
    }

    var totalPriceWithBonus = Number(totalSum) - Number(wallet.bonus)
    var bonusUsed = wallet.bonus

    if (totalPriceWithBonus < 0) {
        totalPriceWithBonus = 0
    } else {
        bonusUsed = Number(totalSum) - totalPriceWithBonus
    }
    
    return {
        'totalPrice': totalSum,
        'totalPriceWithBonus': totalPriceWithBonus,
        'bonusUsed': bonusUsed,
        'newBonus': newBonus,
        'products': products,
        'orderId': order[0].id,
    }
}

OrderService.getCompleted = async (userId) => {
    const rows = await db.Order.findAll({
        where: {
            'userId': userId,
            status: OrderStatusEnum.complete
        }
    })
    
    var items = []
    for (const row of rows) {
        const orderItems = await OrderItemService.all({
            orderId: row.id
        })
        var totalSum = 0
        var productNames = []
        for (const orderItem of orderItems) {
            totalSum += orderItem.productPrice * orderItem.count
            const product = await ProductService.get(orderItem.productId)
            productNames.push(`${product.title} : ${orderItem.count}`)
        }

        items.push({
            receiptDate: formatDateToRussian(row.receiptDate),
            status: row.status,
            'totalSum': totalSum,
            'products': productNames.join("\n")
        })
    }

    return items
}

OrderService.update = async (orderId, options) => {
    return await db.Order.update(
        options,
        {
            where: {
                'id': orderId
            }
        }
    )
}

OrderService.fastBuy = async (userId, productId, count, useBonus = false) => {
    var currentOrder;
    const productItem = await ProductService.get(productId)
    const totalPrice = productItem.price * Number(count)

    const wallet = await UserService.getWallet(userId)

    if (useBonus){
        var totalPriceWithBonus = totalPrice - wallet.bonus
        var bonusUsed = wallet.bonus

        if (totalPriceWithBonus < 0) {
            totalPriceWithBonus = 0
        } else {
            bonusUsed = totalPrice - totalPriceWithBonus
        }

        currentOrder = await db.Order.create({
            'userId': userId,
            status: OrderStatusEnum.complete,
            usedBonus: bonusUsed,
            receiptDate: new Date()
        })
        await UserService.addToWallet(userId, -totalPriceWithBonus, -bonusUsed + productItem.bonus * count)
    } else {
        currentOrder = await db.Order.create({
            'userId': userId,
            status: OrderStatusEnum.complete,
            usedBonus: 0,
            receiptDate: new Date()
        })
        
        await UserService.addToWallet(userId, -totalPrice, productItem.bonus * count)
    }

    const item = await OrderItemService.create(
        currentOrder.id, productItem.id, productItem.price, count
    )

    return currentOrder
}

OrderService.addProduct = async (userId, productId, count) => {
    const currentOrder = await OrderService.getCurrent(userId)
    const productItem = await ProductService.get(productId)

    const item = await OrderItemService.create(
        currentOrder.id, productItem.id, productItem.price, count
    )

    return item
}

OrderService.deleteProduct = async (userId, productId) => {
    const currentOrder = await OrderService.getCurrent(userId)
    const productItem = await ProductService.get(productId)

    const item = await OrderItemService.get({
        orderId: currentOrder.id,
        productId: productItem.id
    })

    return await OrderItemService.delete(item.id)
}

OrderService.complete = async (userId, useBonus) => {
    const items = await OrderService.getCurrentAll(userId)
    if (useBonus) {
        const result = await OrderService.update(items.orderId, {
            status: OrderStatusEnum.complete,
            usedBonus: items.bonusUsed,
            receiptDate: new Date()
        })
        await UserService.addToWallet(userId, -items.totalPriceWithBonus, -items.bonusUsed + items.newBonus)
    } else {
        const result = await OrderService.update(items.orderId, {
            status: OrderStatusEnum.complete,
            usedBonus: 0,
            receiptDate: new Date()
        })
        await UserService.addToWallet(userId, -items.totalPrice, items.newBonus)
    }
}


module.exports = OrderService