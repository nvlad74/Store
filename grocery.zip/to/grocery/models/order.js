'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Order extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      Order.hasMany(models.OrderItem, {
        foreignKey: 'orderId',
        as: 'items'
      })
      Order.belongsTo(models.User, {
        foreignKey: 'userId',
        as: 'user'
      })
    }
  }
  Order.init({
    userId: {
      allowNull: false,
      type: DataTypes.INTEGER
    },
    status: {
      allowNull: false,
      defaultValue: 'Получен',
      type: DataTypes.STRING
    },
    receiptDate: {
      type: DataTypes.DATE
    },
    usedBonus: {
      allowNull: false,
      defaultValue: 0,
      type: DataTypes.DECIMAL
    },
  }, {
    sequelize,
    modelName: 'Order',
  });
  return Order;
};