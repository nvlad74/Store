'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Product extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Product.init({
    title: {
      allowNull: false,
      type: DataTypes.STRING
    },
    price: {
      allowNull: false,
      type: DataTypes.DECIMAL
    },
    image: {
      allowNull: false,
      type: DataTypes.BLOB('long')
    },
    description: {
      allowNull: false,
      type: DataTypes.TEXT
    },
    expirationDate: {
      allowNull: false,
      type: DataTypes.STRING
    },
    storageConditions: {
      allowNull: false,
      type: DataTypes.TEXT
    },
    bonus: {
      allowNull: false,
      type: DataTypes.DECIMAL
    }
  }, {
    sequelize,
    modelName: 'Product',
  });
  Product.findByPk()
  return Product;
};